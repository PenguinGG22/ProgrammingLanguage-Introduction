#include <stdio.h>

int main() {

	printf("Hello, Computer Programming!");

	return 0;
}