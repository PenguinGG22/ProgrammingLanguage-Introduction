// Hello, Basic Programming, Fall 2025
// Instructor - Jangwon Lee @ SKKU

#include <stdio.h>

int main() {

	printf("Hello, Computer Programming!");

	return 0;
}
