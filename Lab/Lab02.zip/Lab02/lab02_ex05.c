#include <stdio.h>

int main()
{
    char ch;
    printf("Enter a character: ");
    ch = getchar();
    printf("You have entered a character: ");
    putchar(ch);

    return 0;
}