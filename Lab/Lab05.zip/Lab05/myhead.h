#pragma once

void add(int a, int b);
void multiply(int a, int b);