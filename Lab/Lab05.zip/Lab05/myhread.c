#include <stdio.h>

void add(int a, int b)
{
	printf("Added value=%d\n", a + b);
}
void multiply(int a, int b)
{
	printf("Multiplied value=%d\n", a * b);
}