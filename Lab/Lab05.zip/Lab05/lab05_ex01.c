#include <stdio.h>

int main() {

    // "printf()" belongs to stdio.h
    printf("hello world");

    return 0;
}