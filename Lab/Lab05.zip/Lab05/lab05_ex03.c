#include <stdio.h>

// macro definition
#define LIMIT 10

int main()
{
	for (int i = 0; i < LIMIT; i++) {
		printf("%d \n", i);
	}

	return 0;
}